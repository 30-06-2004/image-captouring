# Image-Caption-tfjs
Image Caption using tfjs and tfjs+nodejs

Im2Txt (Show and tell) image caption inference demo on tfjs 1.2.7 & nodejs

This repository contains demo video showing inference ,saved_model,packaage.json . For post processing js file, Open an issue or  contact me : vaibhavddit@gmail.com

Web Model files  (converted from tfjs converter):
https://drive.google.com/file/d/1JzUmSnGkPh4ld1xJ8AEirJ19qu0qvtmQ/view?usp=sharing
